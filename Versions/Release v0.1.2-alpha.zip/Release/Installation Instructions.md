# Installation with Stylus

1. Download the latest [release](https://github.com/Kyerstorm/Kenmei-Dark-Mode/releases).

2. Unzip the folder.

3. Install [UserStyles](https://userstyles.org/) to your browser.

4. Open the browser extention by pressing "Manage".

5. Select "Import" under the "Actions" bar on the left-side of the page.

6. Select "Stylus Import.json file you downloaded in Step 1.

7. Enable it by ticking the checkbox next to the name.
**Done**

## Universal Installlation

- Note: due to not all css customisation extentions allowing site-wide customisation, you may have to make multiple profiles for each page.

1. Download the latest [release](https://github.com/Kyerstorm/Kenmei-Dark-Mode/releases).

2. Unzip the folder.

3. Open your preferred css manager.

4. Create a new style, name it and set the relevent Kenmei link.

5. open the "Mozilla Format.css" file with your preferred text editor and copy its contents

6. Paste the contents into your css editor and enable it
**Done**
