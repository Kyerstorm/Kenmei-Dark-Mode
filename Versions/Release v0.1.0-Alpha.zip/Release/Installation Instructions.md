# Installation with Stylus

1. Download the JSON file file in the releases.

2. Install [UserStyles](https://userstyles.org/) to your browser.

3. Open the browser extention by pressing "Manage".

4. Download the JSON file file in the releases.

5. Select "Import" under the "Actions" bar on the left-side of the page.

6. Select the JSON file you downloaded in Step 1.

7. Enable it by ticking the checkbox next to the name.
**Done**
